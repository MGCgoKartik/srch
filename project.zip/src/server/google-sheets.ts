import { google } from 'googleapis';
import path from 'path';

// Define the type for a single row of data based on your columns
// This is a partial type based on the columns you provided.
// You can expand this to include all columns.
export interface SheetRow {
  dealerCode: string;
  dealerName: string;
  branch: string;
  branchName: string;
  orderType: string;
  vehicleId: string;
  model: string;
  variant: string;
  color: string;
  customerName: string;
  mobile: string;
  invoiceNumber: string;
  deliveryDate: string;
  applicationStatus: string;
  financeMode: string;
  fuelType: string;
  [key: string]: any; // Allow other properties
}

const KEY_FILE_PATH = path.join(process.cwd(), 'vehicle-data-465808-db3542c252d2.json');
const SPREADSHEET_ID = '1mfi0JtuIT032ss2I9XdQKFdlGnxrhkyMZJR6iWUIAOE';
const RANGE = 'Sheet1'; // <-- IMPORTANT: REPLACE WITH YOUR SHEET NAME AND RANGE if different

const auth = new google.auth.GoogleAuth({
  keyFile: KEY_FILE_PATH,
  scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
});

async function getSheetData(): Promise<SheetRow[]> {
  try {
    const client = await auth.getClient();
    const sheets = google.sheets({ version: 'v4', auth: client });

    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: RANGE,
    });

    const rows = response.data.values;

    if (!rows || rows.length === 0) {
      console.log('No data found.');
      return [];
    }

    const header = rows[0].map(h => h.replace(/\s+/g, '')); // Remove spaces for key mapping
    const data = rows.slice(1).map((row) => {
      const rowData: { [key: string]: any } = {};
      header.forEach((key, index) => {
        rowData[key] = row[index];
      });
      return rowData as SheetRow;
    });

    return data;
  } catch (err) {
    console.error('Error reading from Google Sheet:', err);
    throw new Error('Failed to fetch data from Google Sheet');
  }
}

export { getSheetData };
