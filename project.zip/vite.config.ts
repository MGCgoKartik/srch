import { defineConfig, Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { getSheetData } from './src/server/google-sheets';

// Custom plugin to create a server-side endpoint for Google Sheets data
const googleSheetsApiPlugin = (): Plugin => ({
  name: 'google-sheets-api',
  configureServer(server) {
    server.middlewares.use('/api/sheet-data', async (req, res, next) => {
      try {
        const data = await getSheetData();
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify(data));
      } catch (error) {
        console.error('API Error:', error);
        res.statusCode = 500;
        res.end(JSON.stringify({ error: 'Failed to fetch data from Google Sheet' }));
      }
    });
  },
});

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), googleSheetsApiPlugin()],
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
});

